// Utility scaffold.
