// Feature scaffold.
