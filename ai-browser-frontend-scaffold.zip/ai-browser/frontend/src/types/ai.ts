// Shared type scaffold.
