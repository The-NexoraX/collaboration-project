// Store scaffold.
