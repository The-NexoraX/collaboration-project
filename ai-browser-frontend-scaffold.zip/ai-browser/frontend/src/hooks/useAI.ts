// Hook scaffold.
